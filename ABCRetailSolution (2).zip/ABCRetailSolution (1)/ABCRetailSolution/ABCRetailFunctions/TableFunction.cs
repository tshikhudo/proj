using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Extensions.Logging;
using System.Net;

namespace ABCRetailFunctions
{
    public class TableFunction
    {
        private readonly ILogger _logger;

        public TableFunction(ILoggerFactory loggerFactory)
        {
            _logger = loggerFactory.CreateLogger<TableFunction>();
        }

        [Function("TableFunction")]
        public HttpResponseData Run(
            [HttpTrigger(AuthorizationLevel.Function, "get")] HttpRequestData req)
        {
            _logger.LogInformation("Function executed.");

            var response = req.CreateResponse(HttpStatusCode.OK);
            response.WriteString("Azure Function Running Successfully");

            return response;
        }
    }
}