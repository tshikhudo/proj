using Azure.Data.Tables;
using ABCRetailWebApp.Models;

namespace ABCRetailWebApp.Services
{
    public class TableStorageService
    {
        private readonly TableClient _tableClient;

        public TableStorageService(IConfiguration configuration)
        {
            var connectionString = configuration["AzureStorage:ConnectionString"];
            var tableName = configuration["AzureStorage:TableName"];

            _tableClient = new TableClient(connectionString, tableName);
            _tableClient.CreateIfNotExists();
        }

        public async Task AddCustomerAsync(CustomerEntity customer)
        {
            await _tableClient.AddEntityAsync(customer);
        }

        public async Task<List<CustomerEntity>> GetCustomersAsync()
        {
            var customers = new List<CustomerEntity>();

            await foreach (var customer in _tableClient.QueryAsync<CustomerEntity>())
            {
                customers.Add(customer);
            }

            return customers;
        }
    }
}