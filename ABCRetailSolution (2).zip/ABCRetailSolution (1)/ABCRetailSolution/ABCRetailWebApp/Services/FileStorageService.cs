using Azure.Storage.Files.Shares;

namespace ABCRetailWebApp.Services
{
    public class FileStorageService
    {
        private readonly ShareClient _shareClient;

        public FileStorageService(IConfiguration configuration)
        {
            var connectionString = configuration["AzureStorage:ConnectionString"];
            var shareName = configuration["AzureStorage:FileShareName"];

            _shareClient = new ShareClient(connectionString, shareName);
            _shareClient.CreateIfNotExists();
        }

        public async Task UploadFileAsync(IFormFile file)
        {
            var directory = _shareClient.GetRootDirectoryClient();
            var fileClient = directory.GetFileClient(file.FileName);

            using var stream = file.OpenReadStream();

            await fileClient.CreateAsync(stream.Length);
            await fileClient.UploadAsync(stream);
        }
    }
}