using Azure.Storage.Blobs;

namespace ABCRetailWebApp.Services
{
    public class BlobStorageService
    {
        private readonly BlobContainerClient _container;

        public BlobStorageService(IConfiguration configuration)
        {
            var connectionString = configuration["AzureStorage:ConnectionString"];
            var containerName = configuration["AzureStorage:BlobContainer"];

            _container = new BlobContainerClient(connectionString, containerName);
            _container.CreateIfNotExists();
        }

        public async Task UploadAsync(IFormFile file)
        {
            var blob = _container.GetBlobClient(file.FileName);

            using var stream = file.OpenReadStream();
            await blob.UploadAsync(stream, true);
        }
    }
}