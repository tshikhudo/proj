# ABC Retail Full Azure Solution

## Features
- Azure Table Storage
- Azure Blob Storage
- Azure Queue Storage
- Azure File Shares
- Azure Functions

## Requirements
- Visual Studio 2022
- .NET 8 SDK
- Azure Storage Account

## Running
1. Open solution in Visual Studio
2. Restore NuGet packages
3. Add Azure connection string
4. Run project